from django.apps import AppConfig


class SalerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'saler'
